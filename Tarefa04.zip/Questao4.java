package org.example;

public class Questao4 {
    public static void main(String[] args) {
        // Criação das instâncias de Funcionario, Analista e Gerente
        Funcionario funcionario = new Funcionario("Carlos", 2000.0);
        Analista analista = new Analista("João", 2500.0);
        Gerente gerente = new Gerente("Maria", 3500.0);

        // Cálculo do salário com bônus
        double salarioFuncionario = funcionario.calcularSalarioComBonus();
        double salarioAnalista = analista.calcularSalarioComBonus();
        double salarioGerente = gerente.calcularSalarioComBonus();

        // Exibição dos salários com bônus
        System.out.println("Salário do Funcionário com bônus: " + salarioFuncionario);
        System.out.println("Salário do Analista com bônus: " + salarioAnalista);
        System.out.println("Salário do Gerente com bônus: " + salarioGerente);
    }
}
