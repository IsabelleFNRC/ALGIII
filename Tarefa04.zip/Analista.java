package org.example;

public class Analista extends Funcionario {
    public Analista(String nome, double salario) {
        super(nome, salario);
    }

    public void aplicarBonus() {
        double salarioAtual = getSalario();
        double bonus = salarioAtual * 0.1;
        double novoSalario = salarioAtual + bonus;
        setSalario(novoSalario);
    }

    @Override
    public double calcularSalarioComBonus() {
        double salarioComBonus = getSalario() * 1.1; // bônus de 10%
        return salarioComBonus;
    }
}

