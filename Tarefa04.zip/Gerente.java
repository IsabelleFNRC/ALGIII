package org.example;

public class Gerente extends Funcionario {
    public Gerente(String nome, double salario) {
        super(nome, salario);
    }

    public void aplicarBonus() {
        double salarioAtual = getSalario();
        double bonus = salarioAtual * 0.2;
        double novoSalario = salarioAtual + bonus;
        setSalario(novoSalario);
    }

    @Override
    public double calcularSalarioComBonus() {
        double salarioComBonus = getSalario() * 1.2; // bônus de 20%
        return salarioComBonus;
    }
}

