package org.example;

public class Livro {
    private String titulo;
    private String ISBN;
    private String genero;
    private boolean disponibilidade;

    public Livro(String titulo, String ISBN, String genero) {
        this.titulo = titulo;
        this.ISBN = ISBN;
        this.genero = genero;
        this.disponibilidade = true; // Inicializando como disponível (verdadeiro)
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public boolean isDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(boolean disponibilidade) {
        this.disponibilidade = disponibilidade;
    }
}

