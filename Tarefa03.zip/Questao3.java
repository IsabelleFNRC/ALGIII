package org.example;

public class Questao3 {
    public static void main(String[] args) {
        // Criando um livro
        Livro livro = new Livro("Dom Quixote", "9780199537891", "Romance");
        System.out.println("Título do livro: " + livro.getTitulo());
        System.out.println("ISBN do livro: " + livro.getISBN());
        System.out.println("Gênero do livro: " + livro.getGenero());
        System.out.println("Disponibilidade do livro: " + livro.isDisponibilidade());
        System.out.println();

        // Criando um usuário
        Usuario usuario = new Usuario("123456789", "João Silva");
        System.out.println("CPF do usuário: " + usuario.getCPF());
        System.out.println("Nome do usuário: " + usuario.getNome());

        // Alterando atributos do usuário
        usuario.setCPF("987654321");
        usuario.setNome("Maria Santos");
        System.out.println("Novo CPF do usuário: " + usuario.getCPF());
        System.out.println("Novo nome do usuário: " + usuario.getNome());
    }
}

