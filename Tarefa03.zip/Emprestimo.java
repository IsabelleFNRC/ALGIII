package org.example;

public class Emprestimo {
    private Livro livro;
    private Usuario usuario;

    public Emprestimo(Livro livro, Usuario usuario) {
        this.livro = livro;
        this.usuario = usuario;
    }

    public boolean realizarEmprestimo() {
        if (livro.isDisponibilidade()) {
            livro.setDisponibilidade(false);
            return true;
        } else {
            return false;
        }
    }

    public void realizarDevolucao() {
        livro.setDisponibilidade(true);
    }
}


