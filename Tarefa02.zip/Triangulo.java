package org.example;

public class Triangulo {
    private double area, base, altura;
    private double ladoA, ladoB, ladoC;
    private String tipoTriangulo;

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public void setLadoA(double ladoA) {
        this.ladoA = ladoA;
    }

    public void setLadoB(double ladoB) {
        this.ladoB = ladoB;
    }

    public void setLadoC(double ladoC) {
        this.ladoC = ladoC;
    }

    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public double calcularArea() {
        if (base > 0 && altura > 0) {
            area = base * altura / 2;
            return area;
        } else {
            System.out.println("Os valores de base e altura devem ser maiores do que 0 para o cálculo da área.");
            return 0;
        }
    }

    public double calcularAreaHeron() {
        if (ladoA > 0 && ladoB > 0 && ladoC > 0) {
            double semiPerimetro = (ladoA + ladoB + ladoC) / 2;
            area = (Math.sqrt(semiPerimetro * (semiPerimetro - ladoA) * (semiPerimetro - ladoB) * (semiPerimetro - ladoC)));
            return area;
        } else {
            System.out.println("Os valores de base e altura devem ser maiores do que 0 para o cálculo da área.");
            return 0;
        }
    }

    public String verificarTipoTriangulo() {
        if (ladoA == ladoB && ladoB == ladoC) {
            return "Equilátero"; // Todos os lados são iguais
        } else if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC) {
            return "Isósceles"; // Dois lados são iguais
        } else {
            return "Escaleno"; // Todos os lados são diferentes
        }
    }
}