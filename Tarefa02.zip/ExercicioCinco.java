package org.example;

public class ExercicioCinco {
    public static void main(String[] args) {
        // Criando um triângulo
        Triangulo triangulo = new Triangulo();
        triangulo.setLadoA(3);
        triangulo.setLadoB(4);
        triangulo.setLadoC(5);
        double areaTriangulo = triangulo.calcularAreaHeron();
        System.out.println("A área do triângulo é: " + areaTriangulo);

        // Criando um círculo
        Circulo circulo = new Circulo(2);
        double areaCirculo = circulo.calcularArea();
        System.out.println("A área do círculo é: " + areaCirculo);

        // Criando um retângulo
        Retangulo retangulo = new Retangulo(5, 3);
        double areaRetangulo = retangulo.calcularArea();
        System.out.println("A área do retângulo é: " + areaRetangulo);
    }
}
