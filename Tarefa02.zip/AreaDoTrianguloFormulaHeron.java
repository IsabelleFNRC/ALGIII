package org.example;

public class AreaDoTrianguloFormulaHeron {
    public static void main(String[] args) {
        Triangulo[] triangulos = new Triangulo[2];
        Triangulo t1 = new Triangulo();
        Triangulo t2 = new Triangulo();

        // Cálculo da área pelo método tradicional
        t1.setBase(10);
        t1.setAltura(20);

        t2.setBase(10);
        t2.setAltura(20);

        // Cálculo da área pela Fórmula de Heron
        t1.setLadoA(10);
        t1.setLadoB(20);
        t1.setLadoC(40);

        t2.setLadoA(20);
        t2.setLadoB(30);
        t2.setLadoC(15);

        triangulos[0] = t1;
        triangulos[1] = t2;

        for (int i = 0; i < triangulos.length; i++) {
            System.out.println("Área do triangulo " + i + " pela forma tradicional é " + triangulos[i].calcularArea());
            System.out.println("Área do triangulo " + i + " pela Fórmula de Heron é " + triangulos[i].calcularAreaHeron());
        }
    }
}
