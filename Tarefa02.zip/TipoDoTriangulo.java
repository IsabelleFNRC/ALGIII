package org.example;

public class TipoDoTriangulo {
    public static void main(String[] args) {
        Triangulo[] triangulos = new Triangulo[3];
        Triangulo t1 = new Triangulo();
        Triangulo t2 = new Triangulo();
        Triangulo t3 = new Triangulo();

        t1.setLadoA(10);
        t1.setLadoB(10);
        t1.setLadoC(40);

        t2.setLadoA(20);
        t2.setLadoB(30);
        t2.setLadoC(25);

        t3.setLadoA(10);
        t3.setLadoB(10);
        t3.setLadoC(10);

        triangulos[0] = t1;
        triangulos[1] = t2;
        triangulos[2] = t3;

        for (int i = 0; i < triangulos.length; i++) {
            System.out.println("Tipo do triangulo " + i + " é " + triangulos[i].verificarTipoTriangulo());
        }
    }
}
