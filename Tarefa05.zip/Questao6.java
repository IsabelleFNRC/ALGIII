package org.example;

public class Questao6 {
    public static void main(String[] args) {
        Cachorro cachorro = new Cachorro("Rex");
        Gato gato = new Gato("Frajola");

        System.out.println("Nome do cachorro: " + cachorro.getNome());
        System.out.println("Nome do gato: " + gato.getNome());

        cachorro.emitirSom();
        cachorro.emitirSom(3); // Sobrecarga do método emitirSom() da classe Cachorro

        gato.emitirSom();
    }
}

