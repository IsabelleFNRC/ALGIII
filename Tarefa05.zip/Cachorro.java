package org.example;

public class Cachorro extends Animal {
    public Cachorro(String nome) {
        super(nome);
    }

    @Override
    public void emitirSom() {
        System.out.println("Au Au!");
    }

    public void emitirSom(int intensidade) {
        StringBuilder som = new StringBuilder();
        for (int i = 0; i < intensidade; i++) {
            som.append("Au ");
        }
        System.out.println(som.toString().trim() + "!");
    }
}

