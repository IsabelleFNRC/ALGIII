import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Animal> animais = new ArrayList<>();

        Cachorro cachorro = new Cachorro("Rex");
        Gato gato = new Gato("Frajola");

        animais.add(cachorro);
        animais.add(gato);

        for (Animal animal : animais) {
            System.out.println("Nome do animal: " + animal.getNome());
            animal.emitirSom();

            if (animal instanceof Brincavel) {
                Brincavel brincavel = (Brincavel) animal;
                brincavel.brincar();
            }

            System.out.println();
        }
    }
}
