public interface Brincavel {
    void brincar();
}